# Mobility


## Module parameters

## get_trip_probabilities_per_day_type

### get_trip_probabilities_per_day_type_other_vehicles
### get_car_trip_probabilities_per_day_type

## compute_start_location_split


## make_mobility_data
### Weighted quantities

## get_day_type_start_location_split

## get_run_mobility_matrix