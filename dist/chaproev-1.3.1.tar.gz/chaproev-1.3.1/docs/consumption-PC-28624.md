
## create_consumption_tables

### Source column
[in the scenario](scenario.md#kilometers_column_for_consumption)