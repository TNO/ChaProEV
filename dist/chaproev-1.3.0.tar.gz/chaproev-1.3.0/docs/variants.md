

For more details, see the 
[documentation of the make_variants.py code file](make_variants.md)