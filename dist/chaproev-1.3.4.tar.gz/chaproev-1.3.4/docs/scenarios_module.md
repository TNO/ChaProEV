



## Generate profiles from sessions