.. ChaProEV documentation master file, created by
   sphinx-quickstart on Mon Apr 29 18:35:36 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ChaProEV's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================


* :ref:`search`
