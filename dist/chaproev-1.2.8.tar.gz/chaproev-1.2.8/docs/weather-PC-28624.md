

## Range and temperature

## get_scenario_weather_data

## get_EV_tool_data
