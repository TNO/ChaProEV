# Approach

## Home type split
vbmn

## Sessions
hhgjh

## Standard profiles
ghjkg