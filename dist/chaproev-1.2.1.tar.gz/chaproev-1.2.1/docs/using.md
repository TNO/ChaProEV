# Installation
```
pip install ChaProEV
```